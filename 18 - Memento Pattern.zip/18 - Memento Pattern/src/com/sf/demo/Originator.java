package com.sf.demo;

public interface Originator {
	public Memento createMemento();
	public void restoreFromMemento(Memento memento);
}
