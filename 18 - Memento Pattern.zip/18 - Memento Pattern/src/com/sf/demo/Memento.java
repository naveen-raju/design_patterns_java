package com.sf.demo;

import java.util.Date;

public class Memento {
	private String state;
	private Date createdOn;

	public Memento(String state) {
		this.state = state;
		this.createdOn = new Date();
	}

	public String getState() {
		return state;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

}
