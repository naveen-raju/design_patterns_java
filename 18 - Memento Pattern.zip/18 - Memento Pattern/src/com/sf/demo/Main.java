package com.sf.demo;

public class Main {
	public static void main(String[] args) {
		Caretaker c = new Caretaker();
		Employee e1 = new Employee(7788, "Scott", 2200);
		c.addMemento(e1.createMemento());

		e1.setSalary(e1.getSalary() + 150);
		c.addMemento(e1.createMemento());

		e1.setSalary(e1.getSalary() + 250);
		c.addMemento(e1.createMemento());

		e1.setSalary(e1.getSalary() + 100);
		c.addMemento(e1.createMemento());

		e1.setSalary(e1.getSalary() + 450);
		c.addMemento(e1.createMemento());

		System.out.println(e1);
		System.out.println("---------------------");

		Employee e2 = new Employee();
		e2.restoreFromMemento(c.getLatestMemento());
		
		System.out.println(e2);

	}
}
