package com.sf.demo;

import java.util.ArrayList;
import java.util.List;

public class Caretaker {
	private List<Memento> savedStates;

	public Caretaker() {
		savedStates = new ArrayList<Memento>();
	}

	public void addMemento(Memento memento) {
		savedStates.add(memento);
	}

	public Memento getLatestMemento() {
		int index = savedStates.size() - 1;
		if (index >= 0) {
			Memento memento = savedStates.get(index);
			savedStates.remove(index);
			return memento;
		}
		return null;
	}
}





