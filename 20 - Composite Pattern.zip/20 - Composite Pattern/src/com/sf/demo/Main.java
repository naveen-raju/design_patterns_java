package com.sf.demo;

public class Main {
	public static void main(String[] args) {
		Directory d1, d2, d3;
		d1 = new Directory("Dir1");
		d2 = new Directory("Dir2");
		d3 = new Directory("Dir3");
		
		d1.addFile(new File("File1", "Vinod"));
		d1.addFile(new File("File2", "Ramesh"));
		d1.addFile(new File("File3", "Vinay"));
		d1.addFile(d2);
		
		d2.addFile(d3);
		
		d3.addFile(new File("File4", "Kumar"));
		d3.addFile(new File("File5", "Kumar"));
		
		d1.printInfo();
		
	}
}
