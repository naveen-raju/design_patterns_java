package com.sf.demo;

public interface AbstractFile {
	StringBuffer indent = new StringBuffer();
	void printInfo();
}
