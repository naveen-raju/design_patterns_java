package com.sf.demo;

import java.util.ArrayList;
import java.util.List;

public class Directory implements AbstractFile {

	String name;
	List<AbstractFile> files;

	public Directory(String name) {
		this.name = name;
		files = new ArrayList<AbstractFile>();
	}

	public void addFile(AbstractFile file) {
		files.add(file); // adding file/directory to "this"
	}

	@Override
	public void printInfo() {
		
		System.out.printf(indent.toString() + "Dir[%s, files:%d]\n", name,
				files.size());
		indent.append("   ");
		
		if (files.size() > 0) {
			for (AbstractFile file : files) {
				file.printInfo();
			}
		}
		indent.setLength(indent.length() - 3);
	}

}
