package com.sf.demo;

public class Cat extends Animal {
	@Override
	public String toString() {
		return "Meow...";
	}
}
