package com.sf.demo;

public class Animal implements Cloneable {

	public Object duplicate() {
		try {
			return super.clone();
		} catch (CloneNotSupportedException e) {
			System.out.println("Can't duplicate now!");
		}
		return null;
	}
}
