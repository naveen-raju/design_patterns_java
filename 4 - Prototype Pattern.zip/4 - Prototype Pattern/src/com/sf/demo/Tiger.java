package com.sf.demo;

public class Tiger extends Animal {
	
	public Tiger() {
		System.out.println("Tiger instaciated...");
	}

	@Override
	public String toString() {
		return "Grr...";
	}
}
