package com.sf.client;

import com.sf.demo.Animal;
import com.sf.demo.Tiger;

public class Program01 {
	public static void main(String[] args) {
		Animal a, b, c;
		
		a = new Tiger();
		
		b = (Animal) a.duplicate();
		c = (Animal) a.duplicate();
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		
	}
}
