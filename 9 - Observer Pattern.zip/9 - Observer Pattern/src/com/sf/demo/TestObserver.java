package com.sf.demo;

import java.util.Arrays;
import java.util.Date;

public class TestObserver implements Observer {

	@Override
	public void notify(Date when, String sql, Object... params) {
		System.out.println("Recieved a notification from server:");
		System.out.println("This SQL was executed by the database at: " + when);
		System.out.println("SQL = " + sql);
		System.out.println("Params = " + Arrays.toString(params));
		System.out.println();
	}

}
