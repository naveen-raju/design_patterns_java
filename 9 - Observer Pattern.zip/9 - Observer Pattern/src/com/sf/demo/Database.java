package com.sf.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class Database {
	
	// methods to represent a subject (publisher)
	
	// this class being a publisher, should maintain a collection of
	// observers
	List<Observer> oservers = new ArrayList<Observer>();
	
	public void registerBeforeExecuteObserver(Observer observer){
		oservers.add(observer);
	}
	public void unregisterBeforeExecuteObserver(Observer observer){
		oservers.remove(observer);
	}
	
	public void notifyAllAboutExecuteUpdate(String sql, Object...params){
		// loop over all the observers and notify them about this event
		for(Observer o: oservers){
			o.notify(new Date(), sql, params);
		}
	}
	
	// -- end of methods to represent a subject (publisher)

	public void executeUpdate(String sql, Object...params){
		// firing the event
		notifyAllAboutExecuteUpdate(sql, params);
		
		System.out.println(getClass().getName()+": executing " 
			+ sql + " with arguments " + Arrays.toString(params));
		
		
	}
}
