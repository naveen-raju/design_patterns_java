package com.sf.demo;

import java.util.Date;

public interface Observer {
	public void notify(Date when, String sql, Object...params);
}
