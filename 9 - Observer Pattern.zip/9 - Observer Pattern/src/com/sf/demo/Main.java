package com.sf.demo;

import java.util.Date;

public class Main {
	public static void main(String[] args) {
		Database db = new Database();
		TestObserver to = new TestObserver();
		db.registerBeforeExecuteObserver(to);
		db.registerBeforeExecuteObserver(new Observer() {
			@Override
			public void notify(Date when, String sql, Object... params) {
				System.out
						.println("On " + when + "'" + sql + "' was executed.");
			}
		});
		
		String sql = "select * from products where price between ? and ?";
		db.executeUpdate(sql, 10, 20);
		db.executeUpdate("show tables");
	}
}
