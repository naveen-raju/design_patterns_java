package com.sf.demo;

public class StockOffer {
	private String stock; // symbol
	private int shares;
	private Colleague colleague;

	public StockOffer(String stock, int shares, Colleague colleague) {
		this.stock = stock;
		this.shares = shares;
		this.colleague = colleague;
	}

	public String getStock() {
		return stock;
	}

	public void setStock(String stock) {
		this.stock = stock;
	}

	public int getShares() {
		return shares;
	}

	public void setShares(int shares) {
		this.shares = shares;
	}

	public Colleague getColleague() {
		return colleague;
	}

	public void setColleague(Colleague colleague) {
		this.colleague = colleague;
	}

}


