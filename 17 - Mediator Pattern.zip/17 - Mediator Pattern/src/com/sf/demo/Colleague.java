package com.sf.demo;

public class Colleague {
	private String name;
	private Mediator mediator;
	
	public Colleague(String name, Mediator mediator){
		this.name = name;
		this.mediator = mediator;
		mediator.addColleague(this);
		System.out.println(name + " joined the stock exchange.");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void saleOffer(String stock, int shares){
		mediator.saleOffer(stock, shares, this);
	}
	
	public void buyOffer(String stock, int shares){
		mediator.buyOffer(stock, shares, this);
	}
	
}











