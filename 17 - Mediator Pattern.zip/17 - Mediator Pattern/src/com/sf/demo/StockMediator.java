package com.sf.demo;

import java.util.ArrayList;
import java.util.List;

public class StockMediator implements Mediator {

	List<Colleague> colleagues;
	List<StockOffer> stockSaleOffers;
	List<StockOffer> stockBuyOffers;

	public StockMediator() {
		colleagues = new ArrayList<Colleague>();
		stockSaleOffers = new ArrayList<StockOffer>();
		stockBuyOffers = new ArrayList<StockOffer>();
	}

	@Override
	public void addColleague(Colleague colleague) {
		colleagues.add(colleague);
	}

	@Override
	public void saleOffer(String stock, int shares, Colleague colleague) {
		boolean stockSold = false;

		for (StockOffer offer : stockBuyOffers) {
			/*
			 * The symbol and count must match.
			 */
			if (offer.getStock().equals(stock) && offer.getShares() == shares) {
				System.out.println(
					shares + " shares of " + stock + "owned by " 
					+ colleague.getName() + " sold to "
					+ offer.getColleague().getName());
				stockBuyOffers.remove(offer);
				stockSold = true;
				break;
			}
		}

		if(!stockSold){
			StockOffer offer = new StockOffer(stock, shares, colleague);
			stockSaleOffers.add(offer);
			
			String msg = "%d shares of %s owned by %s added to inventory\n";
			System.out.printf(msg, shares, stock, colleague.getName());
		}
	}

	@Override
	public void buyOffer(String stock, int shares, Colleague colleague) {
		boolean stockBought = false;
		
		for(StockOffer offer: stockSaleOffers){
			
			/*
			 * The symbol and count must match.
			 */
			if (offer.getStock().equals(stock) && offer.getShares() == shares) {
				String msg = "%s bought %d shares of %s owned by %s\n";
				System.out.printf(msg, 
						colleague.getName(),
						shares,
						stock,
						offer.getColleague().getName());
				stockSaleOffers.remove(offer);
				stockBought = true;
				break;
			}
		}
		
		if(!stockBought){
			StockOffer offer = new StockOffer(stock, shares, colleague);
			stockBuyOffers.add(offer);
			
			String msg = "%s is willing to buy %d shares of %s\n";
			System.out.printf(msg, colleague.getName(), shares, stock);
		}
	}

}











