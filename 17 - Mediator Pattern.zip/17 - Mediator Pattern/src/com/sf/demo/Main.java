package com.sf.demo;

public class Main {
	public static void main(String[] args) {
		
		StockMediator sm = new StockMediator();
		
		Colleague scott = new Colleague("Scott", sm);
		Colleague miller = new Colleague("Miller", sm);
		Colleague robert = new Colleague("Robert", sm);
		
		scott.saleOffer("MSFT", 100);
		scott.saleOffer("GOOG", 120);
		miller.buyOffer("DELL", 500);
		miller.buyOffer("MSFT", 100);
		robert.buyOffer("MSFT", 100);
		
	}
}
