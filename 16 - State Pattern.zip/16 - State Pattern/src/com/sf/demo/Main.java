package com.sf.demo;

public class Main {
	public static void main(String[] args) {
		Applicant suresh, ramesh, harish, umesh;

		suresh = new Applicant();
		ramesh = new Applicant();
		harish = new Applicant();
		umesh = new Applicant();

		suresh.applyForJob();
		ramesh.applyForJob();
		harish.applyForJob();
		umesh.applyForJob();
		
		suresh.checkResume();
		ramesh.checkResume();
		harish.checkResume();
		umesh.checkResume();
	}
}
