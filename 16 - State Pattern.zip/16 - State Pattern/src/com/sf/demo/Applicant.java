package com.sf.demo;

import java.util.Random;

public class Applicant {
	// various possible states

	final static int NO_MORE_JOBS = 0;
	final static int WAITING = 1;
	final static int GOT_A_RESUME = 2;
	final static int JOB_GIVEN = 3;

	static int numberOfJobs=3;
	int state = WAITING;

//	public Applicant(int numberOfJobs) {
//		this.numberOfJobs = numberOfJobs;
//	}

	public void applyForJob() {
		switch (state) {
		case NO_MORE_JOBS:
			System.out.println("Sorry, all jobs are taken.");
			break;
		case WAITING:
			state = GOT_A_RESUME;
			System.out.println("Thanks for applying. We will get back soon.");
			break;
		case GOT_A_RESUME:
			System.out.println("We already have received your resume.");
			break;
		case JOB_GIVEN:
			System.out
					.println("Hang on, we are processing your appointment letter.");
		}
	}

	public void checkResume() {
		switch (state) {
		case NO_MORE_JOBS:
			System.out.println("Sorry, all jobs are taken.");
			break;
		case WAITING:
			System.out.println("You have to apply first, before checking in..");
			break;
		case GOT_A_RESUME:
			int flag = new Random(System.currentTimeMillis()).nextInt()%10;
			if (flag < 5) {
				System.out.println("Congratulations, you got a job!");
				state = JOB_GIVEN;
				// give the appointment letter
				numberOfJobs--;
				if(numberOfJobs==0){
					state = NO_MORE_JOBS;
				}
			} else {
				System.out
						.println("Sorry, you need to try again after 6 months.");
				state = WAITING;
			}
			break;
		case JOB_GIVEN:
			System.out
				.println("Hang on, we are processing your appointment letter.");

		}
	}
}


