package com.sf.demo;

public class Tobacco extends Category {
	private double price;

	public Tobacco(double price) {
		this.price = price;
	}

	public double getPrice() {
		return price;
	}

}
