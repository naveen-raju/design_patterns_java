package com.sf.demo;

public class Main {
	public static void main(String[] args) {
		Visitor visitor = new TaxVisitor();
		Milk m = new Milk(28.0);
		Tobacco t = new Tobacco(55.0);
		Liquor l = new Liquor(900.0);

		System.out.println(m.accept(visitor));
		System.out.println(t.accept(visitor));
		System.out.println(l.accept(visitor));

		System.out.println("During holidays...");

		visitor = new HolidaysTaxVisitor();
		System.out.println(m.accept(visitor));
		System.out.println(t.accept(visitor));
		System.out.println(l.accept(visitor));

		System.out.println();
		visitor = new DiscountVisitor();
		
		System.out.println("During the holidays, the discount is...");
		System.out.println("For milk: " + m.accept(visitor)*100 + "%");
		System.out.println("For tobacco: " + t.accept(visitor)*100 + "%");
	}
}













