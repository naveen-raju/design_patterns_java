package com.sf.demo;

public class DiscountVisitor implements Visitor {

	@Override
	public double visit(Category category) {
		if (category instanceof Liquor) {
			return 0.3;
		} else if (category instanceof Milk) {
			return 0.5;
		} else if (category instanceof Tobacco) {
			return 0.2;
		}
		return 0;
	}

}
