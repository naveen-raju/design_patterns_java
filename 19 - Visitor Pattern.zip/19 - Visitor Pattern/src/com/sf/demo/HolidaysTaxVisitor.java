package com.sf.demo;

public class HolidaysTaxVisitor implements Visitor {

	public double visit(Liquor liquor) {
		System.out.println("Price of liquor after tax:");
		return liquor.getPrice() + liquor.getPrice() * 0.15;
	}

	public double visit(Tobacco tobacco) {
		System.out.println("Price of tobacco after tax:");
		return tobacco.getPrice() + tobacco.getPrice() * 0.20;
	}

	public double visit(Milk milk) {
		System.out.println("Price of milk after tax:");
		return milk.getPrice() + milk.getPrice() * 0.0;
	}

	@Override
	public double visit(Category category) {
		if (category instanceof Liquor) {
			return visit((Liquor) category);
		} else if (category instanceof Milk) {
			return visit((Milk) category);
		} else if (category instanceof Tobacco) {
			return visit((Tobacco) category);
		}
		return 0;
	}
}
