package com.sf.demo;

public interface Visitable {
	public double accept(Visitor visitor);
}
