package com.sf.demo;

public class Liquor extends Category {
	private double price;

	public Liquor(double price) {
		this.price = price;
	}

	public double getPrice() {
		return price;
	}

}
