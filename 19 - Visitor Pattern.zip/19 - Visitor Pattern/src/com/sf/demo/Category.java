package com.sf.demo;

public class Category implements Visitable {

	@Override
	public double accept(Visitor visitor) {
		return visitor.visit(this);
	}

}
