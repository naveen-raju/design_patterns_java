package com.sf.demo;

public interface Visitor {
	public double visit(Category category);
}
