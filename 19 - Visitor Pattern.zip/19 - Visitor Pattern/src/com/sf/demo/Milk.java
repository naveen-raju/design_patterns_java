package com.sf.demo;

public class Milk extends Category {

	private double price;

	public Milk(double price) {
		this.price = price;
	}

	public double getPrice() {
		return price;
	}

}
