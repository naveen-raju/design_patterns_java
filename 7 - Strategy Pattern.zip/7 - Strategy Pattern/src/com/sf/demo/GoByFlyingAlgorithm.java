package com.sf.demo;

public class GoByFlyingAlgorithm implements GoAlogrithm {

	@Override
	public void go() {
		System.out.println("Now I am flying....");
	}

}
