package com.sf.demo;

public class Car extends Vehicle {

	public Car() {
		setGoAlgorithm(new GoByDrivingAlgorithm());
	}
}
