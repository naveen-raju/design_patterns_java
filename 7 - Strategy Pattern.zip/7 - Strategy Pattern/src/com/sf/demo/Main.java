package com.sf.demo;

public class Main {
	public static void main(String[] args) {
		Car c1 = new Car();
		c1.go();
		
		RacingCar rc1 = new RacingCar();
		rc1.go();
		
		Helicopter h1 = new Helicopter();
		h1.go();
		
		Aeroplane a1 = new Aeroplane();
		a1.go();
	}
}
