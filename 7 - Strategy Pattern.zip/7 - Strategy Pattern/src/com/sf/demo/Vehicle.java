package com.sf.demo;

public abstract class Vehicle {
	
	// HAS-A
	private GoAlogrithm goAlgorithm;
	
	public Vehicle() {
	}
	
	// an object of a vehicle must be set with the go-algorithm
	public void setGoAlgorithm(GoAlogrithm goAlgorithm) {
		this.goAlgorithm = goAlgorithm;
	}
	
	public void go(){
		goAlgorithm.go();
	}
}
