package com.sf.demo;

public class Helicopter extends Vehicle {

	public Helicopter() {
		setGoAlgorithm(new GoByFlyingAlgorithm());
	}
}
