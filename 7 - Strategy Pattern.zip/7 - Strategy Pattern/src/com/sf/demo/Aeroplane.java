package com.sf.demo;

public class Aeroplane extends Vehicle {

	public Aeroplane() {
		setGoAlgorithm(new GoByFlyingAlgorithm());
	}
}
