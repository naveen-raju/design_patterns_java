package com.sf.demo;

// any class such a Car (four wheeler), that needs the mechanism for
// going, it can use this algorithm
public class GoByDrivingAlgorithm implements GoAlogrithm {

	@Override
	public void go() {
		System.out.println("Now I am driving...");
	}

}
