package com.sf.demo;

public class RacingCar extends Vehicle {

	public RacingCar() {
		setGoAlgorithm(new GoByDrivingAlgorithm());
	}
}
