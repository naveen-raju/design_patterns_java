package com.sf.demo;

public interface GoAlogrithm {
	public void go();
}
