package com.sf.client;

import com.sf.service.AccountService;
import com.sf.service.AccountService.AccountServiceType;

public class Program01 {
	public static void main(String[] args) {
		AccountService service1 =
			AccountService.getInstance(AccountServiceType.SINGLETON);
		
		AccountService service2 =
			AccountService.getInstance(AccountServiceType.SINGLETON);
		
		System.out.println("service1==service2 is " 
			+ (service1==service2));
		
	}
}
