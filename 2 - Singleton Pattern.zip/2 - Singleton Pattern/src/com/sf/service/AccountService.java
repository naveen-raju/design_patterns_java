package com.sf.service;

public class AccountService {
	
	
	
	public enum AccountServiceType{
		SINGLETON, PROTOTYPE
	}
	
	private static AccountService accountService = null;
	

	// restrict the user not to create an instance
	private AccountService(){
	}
	
	public static AccountService getInstance(AccountServiceType type){
		if(type==AccountServiceType.PROTOTYPE){
			return new AccountService();
		}
		else{
			if(accountService==null){
				accountService = new AccountService();
			}
		}
		return accountService;
	}
	
	// lots of service methods 
	// to be written here:
}
