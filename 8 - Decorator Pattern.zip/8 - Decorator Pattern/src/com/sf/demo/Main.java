package com.sf.demo;

public class Main {
	public static void main(String[] args) {
		
		Computer computer = new Computer();
		computer = new Disk(computer);
		computer = new Monitor(computer);
		computer = new CdPlayer(computer);
		computer = new CdPlayer(computer);
		
		System.out.println(computer.getDescription());
	}
}
