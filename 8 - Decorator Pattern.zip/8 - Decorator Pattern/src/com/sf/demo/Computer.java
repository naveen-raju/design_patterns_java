package com.sf.demo;

public class Computer {
	public Computer() {
	}

	public String getDescription(){
		return "You are getting a computer";
	}
}
