package com.sf.demo;

public class Disk extends ComputerDecorator {

	private Computer computer;

	public Disk(Computer computer) {
		this.computer = computer;
	}

	@Override
	public String getDescription() {
		return computer.getDescription() + ", harddisk";
	}

}
