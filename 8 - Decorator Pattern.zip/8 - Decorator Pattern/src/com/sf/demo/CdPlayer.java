package com.sf.demo;

public class CdPlayer extends ComputerDecorator {

	private Computer computer;

	public CdPlayer(Computer computer) {
		this.computer = computer;
	}

	@Override
	public String getDescription() {
		return computer.getDescription() + ", CD Player";
	}

}
