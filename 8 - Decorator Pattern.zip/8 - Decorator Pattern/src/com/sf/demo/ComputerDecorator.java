package com.sf.demo;

public abstract class ComputerDecorator extends Computer {
	public abstract String getDescription();
}
