package com.sf.demo;

public class Monitor extends ComputerDecorator {

	private Computer computer;

	public Monitor(Computer computer) {
		this.computer = computer;
	}

	@Override
	public String getDescription() {
		return computer.getDescription() + ", monitor";
	}

}
