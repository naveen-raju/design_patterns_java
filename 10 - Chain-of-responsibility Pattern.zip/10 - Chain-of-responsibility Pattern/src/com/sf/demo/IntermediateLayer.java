package com.sf.demo;

public class IntermediateLayer implements HelpInterface {

	private final int INTERMEDIATE_LAYER = 2;
	private HelpInterface successor;
	
	public IntermediateLayer(HelpInterface successor) {
		this.successor = successor;
	}
	
	@Override
	public void getHelp(int helpLevel) {
		if (helpLevel != INTERMEDIATE_LAYER) {
			successor.getHelp(helpLevel);
		}
		else{
			System.out.println("This is the help from the intermediate layer.");
		}
	}

}
