package com.sf.demo;

public interface HelpInterface {
	public void getHelp(int helpLevel);
}
