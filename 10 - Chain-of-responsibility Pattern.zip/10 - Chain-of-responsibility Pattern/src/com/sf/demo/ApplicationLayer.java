package com.sf.demo;

public class ApplicationLayer implements HelpInterface {

	public ApplicationLayer() {
	}

	@Override
	public void getHelp(int helpLevel) {
		System.out.println("This is the help from the application layer.");
	}

}
