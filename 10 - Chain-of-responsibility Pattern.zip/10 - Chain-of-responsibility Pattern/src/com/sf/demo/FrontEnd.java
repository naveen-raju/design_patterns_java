package com.sf.demo;

public class FrontEnd implements HelpInterface {

	private final int FRONT_END_HELP = 1;
	private HelpInterface successor;

	public FrontEnd(HelpInterface successor) {
		this.successor = successor;
	}

//	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain){
//		// process the request (or response)
//		// invoke the next filter
//		chain.doFilter(request, response, chain);
//	}
	
	@Override
	public void getHelp(int helpLevel) {
		if (helpLevel != FRONT_END_HELP) {
			successor.getHelp(helpLevel);
		}
		else{
			System.out.println("This is the help from the front-end.");
		}
	}

}
