package com.sf.demo;

public class Main {
	public static void main(String[] args) {
		
		
		// relatable to Eclipse IDE
		ApplicationLayer al = new ApplicationLayer();
		
		// relatable to Preferences dialog box, originating from IDE
		IntermediateLayer il = new IntermediateLayer(al);
		
		// relatable to "AddNewJRE" dialog box, originating from preferences
		FrontEnd fe = new FrontEnd(il);
		
		fe.getHelp(67);
	}
}
