package com.sf.dao;

import java.util.ResourceBundle;

/*
 * This class needs to create an object of an appropriate DAO
 * implementation and to decide that, we need to communicate the
 * type of implementation we need.
 * 
 * One of the method is to read the required implementation from
 * a property file
 * 
 * Another method is to ask the user via method argument.
 */
public class DaoFactory {
	public static final String HIBERNATE =
		"com.sf.dao.AccountDaoHibernateImpl";
	public static final String JDBC =
		"com.sf.dao.AccountDaoJdbcImpl";
	
	public static AccountDao getAccountDao(String impl) 
	throws DaoException{
		try {
			return (AccountDao) Class.forName(impl).newInstance();
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}
	
	public static AccountDao getAccountDao() 
	throws DaoException{
		try {
			ResourceBundle bundle = 
				ResourceBundle.getBundle("com.sf.dao.dao-impl");
			String impl = bundle.getString("account-dao");
			return (AccountDao) Class.forName(impl).newInstance();
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}
}




