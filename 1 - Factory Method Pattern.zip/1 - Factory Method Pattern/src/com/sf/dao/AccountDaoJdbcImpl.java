package com.sf.dao;

import java.util.List;

import com.sf.entity.Account;

public class AccountDaoJdbcImpl implements AccountDao {

	@Override
	public void createAccount(Account account) throws DaoException {
		System.out.println("AccountDaoJdbcImpl.createAccount called.");
		try {
			// do some work using jdbc
		} catch (Exception ex) {
			throw new DaoException(ex);
		}
	}

	@Override
	public Account getAccount(Integer accountId) throws DaoException {
		System.out.println("AccountDaoJdbcImpl.getAccount called.");
		try {
			// do some work using jdbc
		} catch (Exception ex) {
			throw new DaoException(ex);
		}
		return null;
	}

	@Override
	public List<Account> getAllAccounts() throws DaoException {
		System.out.println("AccountDaoJdbcImpl.getAllAccounts called.");
		try {
			// do some work using jdbc
		} catch (Exception ex) {
			throw new DaoException(ex);
		}
		return null;
	}

}
