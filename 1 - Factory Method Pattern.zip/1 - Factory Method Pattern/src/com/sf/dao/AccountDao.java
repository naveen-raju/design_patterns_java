package com.sf.dao;

import java.util.List;

import com.sf.entity.Account;

/*
 * This is what the client (typically the service layer) uses
 */
public interface AccountDao {
	public void createAccount(Account account) throws DaoException;
	public Account getAccount(Integer accountId) throws DaoException;
	public List<Account> getAllAccounts() throws DaoException;
}
