package com.sf.entity;

public class Account {
	// dummy entity class 
	// definition of members not done here.
}
