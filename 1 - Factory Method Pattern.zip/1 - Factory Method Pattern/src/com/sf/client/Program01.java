package com.sf.client;

import com.sf.dao.AccountDao;
import com.sf.dao.DaoException;
import com.sf.dao.DaoFactory;
import com.sf.entity.Account;

public class Program01 {
	public static void main(String[] args) throws DaoException {
		AccountDao dao;
		
		// from the properties file
		dao = DaoFactory.getAccountDao();
		dao.createAccount(new Account());
		dao.getAccount(123);
		dao.getAllAccounts();
		
		System.out.println();
		
		// specific demand
		dao = DaoFactory.getAccountDao(DaoFactory.JDBC);
		dao.createAccount(new Account());
		dao.getAccount(123);
		dao.getAllAccounts();
		
	}
}
