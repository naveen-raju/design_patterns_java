package com.sf.demo;

import java.util.ArrayList;
import java.util.List;

public class Invoker {
	// private Command command;

	private List<Command> commands;

	public Invoker() {
		commands = new ArrayList<Command>();
	}

	// public void setCommand(Command command) {
	// this.command = command;
	// }
	public void addCommand(Command command) {
		commands.add(command);
	}

	public void run() {
		for (Command command : commands) {
			command.execute();
			System.out.println();
		}
	}
}
