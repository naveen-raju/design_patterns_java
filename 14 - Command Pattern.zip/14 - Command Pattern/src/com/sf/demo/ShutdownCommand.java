package com.sf.demo;

public class ShutdownCommand implements Command {

	private Receiver receiver;

	public ShutdownCommand(Receiver receiver) {
		this.receiver = receiver;
	}

	@Override
	public void execute() {
		// job to be done on a particular server
		receiver.connect();
		receiver.shutdown();
		receiver.disconnect();
	}

}
