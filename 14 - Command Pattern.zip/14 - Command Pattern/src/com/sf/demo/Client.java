package com.sf.demo;

public class Client {
	public static void main(String[] args) {
		Invoker invoker = new Invoker();

		// receivers...
		AsiaServer asiaServer = new AsiaServer();
		USServer usServer = new USServer();
		EuroServer euroServer = new EuroServer();
		
		// commands
		ShutdownCommand shutdownAsia = new ShutdownCommand(asiaServer);
		RebootCommand rebootUs = new RebootCommand(usServer);
		
		DiagnosticsCommand diagnoseEuro = new DiagnosticsCommand(euroServer);
		RebootCommand rebootEuro = new RebootCommand(euroServer);
		
		
		invoker.addCommand(shutdownAsia);
		invoker.addCommand(rebootUs);
		invoker.addCommand(diagnoseEuro);
		invoker.addCommand(rebootEuro);
		
		invoker.run();
		
	}
}
