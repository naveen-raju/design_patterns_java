package com.sf.demo;

public class EuroServer implements Receiver {

	@Override
	public void connect() {
		System.out.println("Connectin to Euro server...");
	}

	@Override
	public void disconnect() {
		System.out.println("Disconnecting from Euro server...");
	}

	@Override
	public void reboot() {
		System.out.println("Rebooting the Euro server...");
	}

	@Override
	public void shutdown() {
		System.out.println("Shutting down the Euro server...");
	}

	@Override
	public void runDiagnostics() {
		System.out.println("Running the diagnostic plan on Euro server...");
	}

}
