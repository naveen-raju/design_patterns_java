package com.sf.demo;

public class AsiaServer implements Receiver {

	@Override
	public void connect() {
		System.out.println("Connectin to Asia server...");
	}

	@Override
	public void disconnect() {
		System.out.println("Disconnecting from Asia server...");
	}

	@Override
	public void reboot() {
		System.out.println("Rebooting the Asia server...");
	}

	@Override
	public void shutdown() {
		System.out.println("Shutting down the Asia server...");
	}

	@Override
	public void runDiagnostics() {
		System.out.println("Running the diagnostic plan on Asia server...");
	}

}
