package com.sf.demo;

public class DiagnosticsCommand implements Command {

	private Receiver receiver;

	public DiagnosticsCommand(Receiver receiver) {
		this.receiver = receiver;
	}

	@Override
	public void execute() {
		// job to be done on a particular server
		receiver.connect();
		receiver.runDiagnostics();
		receiver.disconnect();
	}

}
