package com.sf.demo;

public interface Command {
	public void execute();
}
