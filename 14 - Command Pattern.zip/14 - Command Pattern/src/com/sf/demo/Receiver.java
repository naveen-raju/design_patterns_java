package com.sf.demo;

public interface Receiver {
	public void connect();
	public void disconnect();
	public void reboot();
	public void shutdown();
	public void runDiagnostics();
}
