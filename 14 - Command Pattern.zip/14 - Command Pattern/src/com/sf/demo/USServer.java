package com.sf.demo;

public class USServer implements Receiver {

	@Override
	public void connect() {
		System.out.println("Connectin to US server...");
	}

	@Override
	public void disconnect() {
		System.out.println("Disconnecting from US server...");
	}

	@Override
	public void reboot() {
		System.out.println("Rebooting the US server...");
	}

	@Override
	public void shutdown() {
		System.out.println("Shutting down the US server...");
	}

	@Override
	public void runDiagnostics() {
		System.out.println("Running the diagnostic plan on US server...");
	}

}
