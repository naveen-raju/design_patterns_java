package com.sf.demo;

public class RebootCommand implements Command {

	private Receiver receiver;

	public RebootCommand(Receiver receiver) {
		this.receiver = receiver;
	}

	@Override
	public void execute() {
		// job to be done on a particular server
		receiver.connect();
		receiver.reboot();
		receiver.disconnect();
	}

}
