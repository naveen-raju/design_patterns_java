package com.sf.demo;

public interface AceInterface {
	public void setName(String name);

	public String getName();
}
