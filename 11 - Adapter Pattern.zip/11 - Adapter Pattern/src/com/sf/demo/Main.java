package com.sf.demo;

public class Main {
	public static void main(String[] args) {
		AceInterface ace = new AceClass();
		ace.setName("Vinod Kumar");
		
		AcmeInterface acme = new AceToAcmeAdapter(ace);
		
		System.out.println("First name = " + acme.getFirstName());
		System.out.println("Last name = " + acme.getLastName());
	}
}
