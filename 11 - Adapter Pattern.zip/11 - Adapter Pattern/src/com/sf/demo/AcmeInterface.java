package com.sf.demo;

public interface AcmeInterface {
	public void setFirstName(String firstName);

	public String getFirstName();

	public void setLastName(String lastName);

	public String getLastName();

}
