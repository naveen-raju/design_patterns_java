package com.sf.demo;

// relate to InputStreamReader
public class AceToAcmeAdapter extends AcmeClass {
	public AceToAcmeAdapter(AceInterface ace) {
		String[] ar = ace.getName().split(" ");
		setFirstName(ar[0]);
		setLastName(ar[1]);
	}
}
