package com.sf.demo;

// this class can be related to HttpServlet class
public abstract class RobotTemplate {

	// this method can be related to service (protected) method
	// which in turn calls doXXX methods based on the http
	// method used by the client.
	public final void go() {
		start();
		getParts();
		assemble();
		test();
		stop();
	}

	public void start() {
		System.out.println("Starting...");
	}

	public void getParts() {
		System.out.println("getting parts...");
	}

	public void assemble() {
		System.out.println("assembling...");
	}

	public void test() {
		System.out.println("Testing...");
	}

	public void stop() {
		System.out.println("Stopping...");
	}
}
