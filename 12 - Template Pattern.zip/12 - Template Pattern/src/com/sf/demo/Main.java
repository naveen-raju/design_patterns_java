package com.sf.demo;

public class Main {
	public static void main(String[] args) {
		CookieRobot cr1 = new CookieRobot();
		ComputerRobot cr2 = new ComputerRobot();
		
		cr1.go();
		
		System.out.println();
		
		cr2.go();
		
	}
}
