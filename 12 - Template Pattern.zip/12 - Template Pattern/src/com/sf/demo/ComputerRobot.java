package com.sf.demo;

public class ComputerRobot extends RobotTemplate {
	
	@Override
	public void start() {
		System.out.println("Starting build the computer...");
	}
	
	@Override
	public void getParts() {
		System.out.println("Getting CPU, RAM, HDD etc.");
	}
	
	@Override
	public void assemble() {
		System.out.println("Putting all components into motherboard...");
	}
	
	@Override
	public void test() {
		System.out.println("Switching it on...");
	}
	
	@Override
	public void stop() {
		System.out.println("Shutting down the OS...");
	}
}
