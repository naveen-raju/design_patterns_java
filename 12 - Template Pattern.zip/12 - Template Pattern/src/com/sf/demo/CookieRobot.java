package com.sf.demo;

public class CookieRobot extends RobotTemplate {
	@Override
	public void getParts() {
		System.out.println("Getting flour and sugar...");
	}
	
	@Override
	public void assemble() {
		System.out.println("Baking nice sugary cookies...");
	}
	
	@Override
	public void test() {
		System.out.println("Curnching and munching cookies...");
	}
	
}
