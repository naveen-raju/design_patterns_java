package com.sf.demo;

public class AccountServiceImpl implements AccountService {

	@Override
	public void setRole(String role) {
	}

	@Override
	public void addNewAccount() {
		System.out.println("Adding a new account...");
	}

	@Override
	public void deleteAccount() {
		System.out.println("Deleting an existing account...");
	}

	@Override
	public String getAccountInfo() {
		System.out.println("Returning some account information...");
		return null;
	}

	@Override
	public String getBalance() {
		System.out.println("Returning some balance...");
		return null;
	}

}
