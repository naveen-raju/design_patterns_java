package com.sf.demo;

public interface AccountService {
	public void setRole(String role);
	
	// dummy methods; not significant now.
	public void addNewAccount();
	public void deleteAccount();
	public String getAccountInfo();
	public String getBalance();
	
}
