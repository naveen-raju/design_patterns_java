package com.sf.demo;

public class AccountServiceProxy implements AccountService {

	private String role = "GUEST";
	private AccountService target = new AccountServiceImpl();
	
	@Override
	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public void addNewAccount() {
		if(role!=null && role.equalsIgnoreCase("admin")){
			target.addNewAccount();
		}
		else{
			throw new NoAccessException("You do not have access to add");
		}
	}

	@Override
	public void deleteAccount() {
		if(role!=null && role.equalsIgnoreCase("admin")){
			target.deleteAccount();
		}
		else{
			throw new NoAccessException("You do not have access to delete");
		}
	}

	@Override
	public String getAccountInfo() {
		return target.getAccountInfo();
	}

	@Override
	public String getBalance() {
		return target.getBalance();
	}

}
