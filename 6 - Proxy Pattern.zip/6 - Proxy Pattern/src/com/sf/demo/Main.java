package com.sf.demo;

public class Main {
	public static void main(String[] args) {
		AccountService service;
		
		// this instance should be created using a factory,
		// so that the client is unaware of the fact that he/she
		// is dealing with a proxy and not a real service object
		service = new AccountServiceProxy();
		
		service.setRole("vinod");
//		service.addNewAccount(); // error; due to proxy checking
//		service.deleteAccount(); // error; due to proxy checking
		service.getAccountInfo();
		service.getBalance();
	}
}
