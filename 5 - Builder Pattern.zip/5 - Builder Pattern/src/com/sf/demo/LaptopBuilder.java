package com.sf.demo;

public class LaptopBuilder implements ComputerBuilder {

	private Computer computer ;
	
	public LaptopBuilder() {
		computer = new Computer();
	}
	public Computer getComputer() {
		return computer;
	}
	
	@Override
	public void buildProcessor() {
		computer.setProcessor("Intel Core2duo 1.5 GHz");
	}

	@Override
	public void buildMemory() {
		computer.setMemory("2GB DDR3");
	}

	@Override
	public void buildDisplay() {
		computer.setDisplay("10\" Antiglare Monitor");
	}

	@Override
	public void buildHdd() {
		computer.setHdd("320GB SEAGATE SATA");
	}

}
