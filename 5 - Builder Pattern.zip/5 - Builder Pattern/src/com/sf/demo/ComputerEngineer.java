package com.sf.demo;

public class ComputerEngineer {
	private ComputerBuilder builder;

	public ComputerEngineer(ComputerBuilder builder) {
		this.builder = builder;
	}
	
	public void buildComputer(){
		builder.buildDisplay();
		builder.buildHdd();
		builder.buildMemory();
		builder.buildProcessor();
	}
	
	public Computer getComputer(){
		return builder.getComputer();
	}
}
