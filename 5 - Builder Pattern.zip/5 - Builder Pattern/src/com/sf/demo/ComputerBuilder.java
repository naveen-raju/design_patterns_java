package com.sf.demo;

public interface ComputerBuilder {
	
	public Computer getComputer();
	
	public void buildProcessor();
	public void buildMemory();
	public void buildDisplay();
	public void buildHdd();
}
