package com.sf.demo;

public class Computer {
	private String processor;
	private String memory;
	private String hdd;
	private String display;

	public Computer() {
	}

	public String getProcessor() {
		return processor;
	}

	public void setProcessor(String processor) {
		this.processor = processor;
	}

	public String getMemory() {
		return memory;
	}

	public void setMemory(String memory) {
		this.memory = memory;
	}

	public String getHdd() {
		return hdd;
	}

	public void setHdd(String hdd) {
		this.hdd = hdd;
	}

	public String getDisplay() {
		return display;
	}

	public void setDisplay(String display) {
		this.display = display;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Computer [processor=").append(processor)
				.append(", memory=").append(memory).append(", hdd=")
				.append(hdd).append(", display=").append(display).append("]");
		return builder.toString();
	}

}
