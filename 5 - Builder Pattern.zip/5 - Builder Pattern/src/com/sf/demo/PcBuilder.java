package com.sf.demo;

public class PcBuilder implements ComputerBuilder {

	private Computer computer;
	
	public PcBuilder() {
		computer = new Computer();
	}
	
	public Computer getComputer() {
		return computer;
	}
	
	@Override
	public void buildProcessor() {
		computer.setProcessor("Intel Dual Core 3.0 GHz");
	}

	@Override
	public void buildMemory() {
		computer.setMemory("4GB DDR2");
	}

	@Override
	public void buildDisplay() {
		computer.setDisplay("20\" LED Monitor");
	}

	@Override
	public void buildHdd() {
		computer.setHdd("500GB WD SATA");
	}

}
