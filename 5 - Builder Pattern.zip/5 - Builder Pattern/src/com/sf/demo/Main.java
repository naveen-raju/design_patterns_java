package com.sf.demo;

public class Main {
	public static void main(String[] args) {
		LaptopBuilder laptopBuilder = new LaptopBuilder();
		PcBuilder pcBuilder = new PcBuilder();
		ComputerEngineer engineer;
		
		engineer= new ComputerEngineer(laptopBuilder);
		engineer.buildComputer();
		Computer computer = engineer.getComputer();
		System.out.println(computer);

		System.out.println();
		
		engineer= new ComputerEngineer(pcBuilder);
		engineer.buildComputer();
		computer = engineer.getComputer();
		System.out.println(computer);

	}
}
