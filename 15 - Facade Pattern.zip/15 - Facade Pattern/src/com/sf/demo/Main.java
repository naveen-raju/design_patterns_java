package com.sf.demo;

public class Main {
	public static void main(String[] args) {
		
		int accountNumber = 12345678;
		int securityCode = 7788;
		double amount = 1500;
		
		BankAccountFacade facade = new BankAccountFacade(accountNumber, securityCode);
	
		facade.withdrawCash(amount);
		facade.withdrawCash(750);
		facade.withdrawCash(3000);
		
		
	}
}
