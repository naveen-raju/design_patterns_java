package com.sf.demo;

public class FundsManager {
	private double cashInAccount = 5000;

	public double getCashInAccount() {
		return cashInAccount;
	}

	public void increaseCashInAccount(double amount) {
		cashInAccount += amount;
	}

	public void decreaseCashInAccount(double amount) {
		cashInAccount -= amount;
	}

	public boolean isThereEnougCash(double amount) {
		return amount < (cashInAccount - 100);
	}

	public void withdraw(double amount) throws InsufficentFundsException {
		if (isThereEnougCash(amount)) {
			decreaseCashInAccount(amount);
			System.out.printf("$%.2f was successfully "
					+ "withdrawn from your account\n", amount);
			System.out.println("Current balance in your account is $" + cashInAccount);
		} else {

			String msg = "OOPS! Insufficient funds, please retry with a smaller amount";
			throw new InsufficentFundsException(msg);
		}
	}

	public void deposit(double amount) {
		increaseCashInAccount(amount);
		System.out.printf("$%.2f was successfully "
				+ "deposited to your account\n", amount);
	}
}
