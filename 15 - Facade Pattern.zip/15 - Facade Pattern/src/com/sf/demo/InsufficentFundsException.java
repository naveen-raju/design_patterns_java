package com.sf.demo;

public class InsufficentFundsException extends Exception {

	private static final long serialVersionUID = 1L;

	public InsufficentFundsException() {
	}

	public InsufficentFundsException(String message) {
		super(message);
	}

	public InsufficentFundsException(Throwable cause) {
		super(cause);
	}

	public InsufficentFundsException(String message, Throwable cause) {
		super(message, cause);
	}

}
