package com.sf.demo;

public class SecurityCheck {
	private int securityCode = 7788;

	public int getSecurityCode() {
		return securityCode;
	}

	public boolean isCodeCorrect(int code) {
		return code == securityCode;
	}
}
