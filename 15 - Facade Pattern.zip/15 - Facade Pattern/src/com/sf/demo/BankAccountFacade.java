package com.sf.demo;

public class BankAccountFacade {
	private int accountNumber;
	private int securityCode;

	private WelcomeToBank welcomeToBank;
	private AccountNumberCheck accountNumberCheck;
	private SecurityCheck securityCheck;
	private FundsManager fundsManager;

	public BankAccountFacade(int accountNumber, int securityCode) {
		this.accountNumber = accountNumber;
		this.securityCode = securityCode;
		
		/*
		 * Instead of making these (POJO) as instance variables,
		 * you should think of having them as local variables,
		 * created and used with in a method call.
		 * 
		 * Even better, if you can get it from a cache or pool.
		 */
		welcomeToBank = new WelcomeToBank();
		accountNumberCheck = new AccountNumberCheck();
		securityCheck = new SecurityCheck();
		fundsManager = new FundsManager();
	}

	public void withdrawCash(double amount){
		if(accountNumberCheck.isAccountActive(accountNumber)
			&& securityCheck.isCodeCorrect(securityCode)){
			try {
				fundsManager.withdraw(amount);
			} catch (InsufficentFundsException e) {
				System.out.println(e.getMessage());
			}
		}
		else{
			System.out.println("Either account number or security is incorrect.");
		}
	}
	
	public void depositCash(double amount){
		// not done yet.
	}
	
}










