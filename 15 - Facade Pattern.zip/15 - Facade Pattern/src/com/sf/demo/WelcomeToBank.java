package com.sf.demo;

public class WelcomeToBank {
	public WelcomeToBank() {
		System.out.println("Welcome to ACME banking services");
		System.out.println("We are happy to be at your service...");
	}
}
