package com.sf.demo;

import java.util.Iterator;

public class Main {
	public static void main(String[] args) {
		Division d1 = new Division("South");

		d1.addVicePresident("Scott");
		d1.addVicePresident("Miller");
		d1.addVicePresident("Jane");
		d1.addVicePresident("Jones");

		Iterator<VicePresident> i = d1.iterator();
		while (i.hasNext()) {
			VicePresident vp = i.next();
			System.out.println(vp.getName() + " is the vice president of "
					+ vp.getDivision() + " division");
		}
	}
}
