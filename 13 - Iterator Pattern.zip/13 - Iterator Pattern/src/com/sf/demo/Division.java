package com.sf.demo;

import java.util.Iterator;

public class Division {

	private String name;
	private VicePresident[] vps = new VicePresident[100];
	private int index = 0;

	public Division(String name) {
		this.name = name;
	}

	public void addVicePresident(String name) {
		VicePresident vp = new VicePresident(name, this.name);
		vps[index++] = vp;
	}

	public Iterator<VicePresident> iterator() {
		return new DivisionIterator();
	}

	public class DivisionIterator implements Iterator<VicePresident> {

		int number = 0;

		@Override
		public boolean hasNext() {
			return number < index;
		}

		@Override
		public VicePresident next() {
			return vps[number++];
		}

		@Override
		public void remove() {
		}
	}
}
