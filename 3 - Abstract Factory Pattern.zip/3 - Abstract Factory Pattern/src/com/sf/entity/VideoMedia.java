package com.sf.entity;

public class VideoMedia implements Media {

}
