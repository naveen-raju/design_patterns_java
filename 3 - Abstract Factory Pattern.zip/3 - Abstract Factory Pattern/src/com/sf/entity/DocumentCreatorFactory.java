package com.sf.entity;

import java.util.ResourceBundle;

public abstract class DocumentCreatorFactory {

	public static DocumentCreator newInstance(){
		ResourceBundle bundle = 
			ResourceBundle.getBundle("com.sf.entity.document");
		
		try {
			return (DocumentCreator) Class.forName(
				bundle.getString("document.creator")).newInstance();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
