package com.sf.entity;

public interface Media {

}
