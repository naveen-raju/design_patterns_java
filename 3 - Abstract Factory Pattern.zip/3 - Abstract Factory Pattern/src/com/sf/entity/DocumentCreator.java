package com.sf.entity;

public interface DocumentCreator {
	// abstract
	// returns a concrete Letter or Resume
	public Document createDocument();
	public Media createMeadia();
}
