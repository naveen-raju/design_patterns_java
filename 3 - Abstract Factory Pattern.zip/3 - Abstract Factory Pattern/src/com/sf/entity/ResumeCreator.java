package com.sf.entity;

public class ResumeCreator implements DocumentCreator {

	@Override
	public Document createDocument() {
		return new Resume();
	}

	@Override
	public Media createMeadia() {
		// TODO Auto-generated method stub
		return new VideoMedia();
	}

}
