package com.sf.entity;

public class Resume implements Document {

}
