package com.sf.entity;

public class Letter implements Document {

}
