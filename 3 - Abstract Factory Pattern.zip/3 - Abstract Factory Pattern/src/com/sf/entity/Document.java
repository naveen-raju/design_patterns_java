package com.sf.entity;

public interface Document {

}
