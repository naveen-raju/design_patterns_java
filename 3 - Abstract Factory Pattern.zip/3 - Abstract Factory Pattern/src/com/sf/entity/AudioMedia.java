package com.sf.entity;

public class AudioMedia implements Media {

}
