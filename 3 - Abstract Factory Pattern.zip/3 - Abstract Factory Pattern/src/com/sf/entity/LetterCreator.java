package com.sf.entity;

public class LetterCreator implements DocumentCreator {

	@Override
	public Document createDocument() {
		return new Letter();
	}

	@Override
	public Media createMeadia() {
		// TODO Auto-generated method stub
		return new AudioMedia();
	}
	
	

}
