package com.sf.client;

import com.sf.entity.Document;
import com.sf.entity.DocumentCreator;
import com.sf.entity.DocumentCreatorFactory;
import com.sf.entity.Media;

public class Program01 {
	public static void main(String[] args) {
		DocumentCreator dc = DocumentCreatorFactory.newInstance();
		//System.out.println(dc.getClass()); 
		
		Document doc = dc.createDocument();
		System.out.println(doc.getClass());
		
		Media m = dc.createMeadia();
		System.out.println(m.getClass());
	}
}
